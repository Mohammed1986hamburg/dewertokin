
const { app } = require('./handler');


const AWS = require('aws-sdk');
let awsConfig={
    "region": "eu-central-1",
    "endpoint": "http://dynamodb.eu-central-1.amazonaws.com",
    "accessKeyId": "AKIA5P7SSVL3BEQYO2UI", "secretAccessKey": "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"
  };
  AWS.config.update(awsConfig);
var docClient = new AWS.DynamoDB.DocumentClient();

var params = {
    TableName: 'test',
    Key: {
      'email': "best.pid@gmail.com"
    }
  };

const PORT= process.env.PORT || 4000;

app.listen(PORT, async ()=>{

      const data = await docClient.get(params).promise();

      if(data.Item){console.log("Success found", JSON.stringify(data.Item));}
      else {console.log("not found", data.Item);} 
      console.log(`connected to DynamoDB,  server listening on port ${PORT}!`)

      
})
    


   















